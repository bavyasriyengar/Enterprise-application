/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import bean.users;
import javax.servlet.http.HttpSession;
import operations.comoperations;
/**
 *
 * @author minna
 */
public class login extends HttpServlet {

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       String un = request.getParameter("username");
       String pw = request.getParameter("password");
        
        users log = new users();
       
        comoperations c= new comoperations();
        
        log.setUsername(un);
        log.setPassword(pw);
        
        log=c.getLoginDetails(log);
        
        if(log.isValid()){
            request.setAttribute("fname", log.getFname());
            request.setAttribute("lname", log.getLname());
            request.setAttribute("email", log.getEmail());
              //request.setAttribute("domain", log.getDomain());
               
            
            
            
            RequestDispatcher rd= request.getRequestDispatcher("userhome.jsp");
            rd.forward(request, response);
        }
        else{
            response.sendRedirect(request.getContextPath());
        }
        
          /*if(log.isValid()){
            HttpSession session=request.getSession();
            session.setAttribute("currentsession", log);
            response.sendRedirect("userhome.jsp?username="+log.getUsername()+"&password="+log.getPassword());
        }else{
            response.sendRedirect("index.jsp");           
        }*/
    }


}
