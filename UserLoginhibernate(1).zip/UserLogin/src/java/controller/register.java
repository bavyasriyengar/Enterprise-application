/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import bean.users;
import operations.comoperations;
/**
 *
 * @author minna
 */
public class register extends HttpServlet {

RequestDispatcher rd;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter p = response.getWriter();
        String un = request.getParameter("username");
        String pw = request.getParameter("password");
        String n = request.getParameter("firstName");
        String l = request.getParameter("lastName");
        String e = request.getParameter("email");
        int i = Integer.parseInt(request.getParameter("uid"));
        
        users log = new users();
        comoperations c= new comoperations();
        
        log.setUsername(un);
        log.setPassword(pw);
        log.setFname(n);
        log.setLname(l);
        log.setEmail(e);
        log.setUid(i);
        
        
        boolean result = c.register(log);
         /*   if(result){
            request.setAttribute("username", request.getParameter("username"));
            request.setAttribute("msg", "Registration Successful");
            p.println("Registered!");
            
        }else{
            request.setAttribute("username", request.getParameter("username"));
            request.setAttribute("msg", "Registration Failure");
            p.println("failed!");
        }*/
            if(result){
                
                rd = request.getRequestDispatcher("index.jsp");
                rd.forward(request, response);
            }else{
                rd = request.getRequestDispatcher("registeruser.jsp");
                rd.forward(request, response);
            }
    }

    // </editor-fold>

}
