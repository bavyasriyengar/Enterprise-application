/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package operations;
import org.hibernate.cfg.Configuration;
import bean.users;
import java.util.Iterator;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
/**
 *
 * @author minna
 */

public class comoperations {
    Session session = null;
    SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
    
    public users getLoginDetails(users log){
        session=  sessionFactory.openSession();
        session.beginTransaction();
        String un= log.getUsername();
        String pw = log.getPassword();
        String sql_query = "From users log where log.username='"+un+"' and log.password ='"+pw+"' ";
        Query query= (Query) session.createQuery(sql_query);
        System.out.println("Query Result"+query);
        for (Iterator it = query.iterate(); it.hasNext();){
            users l=(users) it.next();
           
            log.setUsername(l.getUsername());
            log.setPassword(l.getPassword());
            log.setFname(l.getFname());
            log.setLname(l.getLname());
            log.setEmail(l.getEmail());
            
            log.setValid(true);
        }
        session.getTransaction().commit();
        session.close();
        
        
        return log;
}
 public boolean register(users log){
        boolean result;
        session = sessionFactory.openSession();
        session.beginTransaction();
        try{
            session.save(log);
            result = true;
        }catch(Exception e){
            result = false;
        }
        session.getTransaction().commit();
        session.close();
        return result;
    }
    
    
    public users getData(String Fname){
        
        session = sessionFactory.openSession();
        session.beginTransaction();
        
        String SQL_QUERY = "From users log where log.username='\" + Fname + \"'";
        Query query = (Query) session.createQuery(SQL_QUERY);
        System.out.println("Query Result : "+query);
        
        
        
        Iterator it1 = query.iterate();
        
        
        users r = new users();
       
            
            r.setFname(r.getFname());
            
        
        session.getTransaction().commit();
        session.close();
        return r;
    }
    
}